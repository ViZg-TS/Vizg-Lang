//! By convention, root.zig is the root source file when making a package.
const std = @import("std");
const Io = std.Io;

pub const frontend = @import("frontend/frontend.zig");
pub const ast = @import("frontend/ast.zig");
pub const binder = @import("frontend/binder.zig");
pub const resolver = @import("frontend/resolver.zig");
pub const cfg = @import("frontend/cfg.zig");
pub const diagnostics = @import("diagnostic/root.zig");
pub const diagnostic = diagnostics;
pub const modules = @import("modules/root.zig");
pub const tokens = @import("frontend/tokens.zig");

/// This is a documentation comment to explain the `printAnotherMessage` function below.
///
/// Accepting an `Io.Writer` instance is a handy way to write reusable code.
pub fn printAnotherMessage(writer: *Io.Writer) Io.Writer.Error!void {
    try writer.print("Run `zig build test` to run the tests.\n", .{});
}

pub fn add(a: i32, b: i32) i32 {
    return a + b;
}

test "basic add functionality" {
    try std.testing.expect(add(3, 7) == 10);
}

test {
    _ = @import("frontend/tokens.zig");
    _ = @import("frontend/scanner.zig");
    _ = @import("frontend/parser.zig");
    _ = @import("frontend/binder.zig");
    _ = @import("frontend/resolver.zig");
    _ = @import("frontend/cfg.zig");
    _ = @import("diagnostic/root.zig");
    _ = @import("modules/root.zig");
    _ = @import("modules/graph.zig");
    _ = @import("modules/loader.zig");
    _ = @import("modules/resolver.zig");
    _ = @import("frontend/tests.zig");
    _ = frontend;
}
